function fprintf(varargin)

end